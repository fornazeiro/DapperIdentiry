﻿namespace Identity.Dapper.Queries.Contracts
{
    public interface IQuery
    {
    }
}
