﻿namespace Identity.Dapper.Queries.Contracts
{
    public interface IDeleteQuery : IQuery
    {
        string GetQuery();
    }
}
