﻿namespace Identity.Dapper.Models
{
    public class DapperIdentityOptions
    {
        public bool UseTransactionalBehavior { get; set; } = false;
    }
}
